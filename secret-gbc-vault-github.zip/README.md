# Secret GBC Vault

GitHub Pages-ready static site.

## Publish
1. Create a GitHub repository.
2. Upload `index.html`.
3. Open **Settings → Pages**.
4. Select **Deploy from a branch**, branch `main`, folder `/ (root)`.
5. Open the generated Pages URL.

The page contains original demo mini-games and a ROM file selector. The selector does not itself execute commercial ROMs; use only ROMs you have the rights to use and add a properly licensed emulator core if you want ROM execution.
