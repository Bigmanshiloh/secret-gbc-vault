# Secret GBC Vault — Full Emulator

GitHub Pages-ready front end for a real browser Game Boy / Game Boy Color emulator.

## Publish
1. Upload `index.html` to the same GitHub repository.
2. Commit the change.
3. Keep GitHub Pages pointed at `main` / `/ (root)`.
4. Open the Pages URL.
5. Choose **INSERT CARTRIDGE** and select a `.gb` or `.gbc` ROM you have the right to use.

## Important
This project does not contain commercial ROMs. The emulator engine is loaded from the EmulatorJS public CDN at runtime. EmulatorJS provides browser emulation and supports Game Boy/Game Boy Color through its cores.

If your school's network blocks `cdn.emulatorjs.org`, the emulator will not load until that domain is permitted; the GitHub page itself can still open.
