SECRET GBC VAULT

1. Open index.html locally to preview the site.
2. The included demos are original mini demos, not commercial ROMs.
3. The ROM picker is a placeholder for a GBC emulator core; it does not execute ROMs by itself.
4. For Google Sites, host this folder on a static host (for example GitHub Pages or another host you control), then embed the published page in Google Sites.
